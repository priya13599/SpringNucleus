package com.nucleus.Util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
@Component
public class EncoderPwd {
	
	
	public static String encodepwd(String password)
	{
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String pwd1 =encoder.encode(password);
		return pwd1;
		
	}
	
	public static void main(String[] args) {
		System.out.println(encodepwd("user01"));
		
	}


}
